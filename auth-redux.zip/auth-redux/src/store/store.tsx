// Імпортуємо кореневу функцію-редюсер з директорії reducers.
import usersSlice from '../reducer/usersSlice'
// // Імпортуємо необхідні типи та функції з бібліотек Redux Toolkit та Redux Thunk.
import { Action, configureStore } from '@reduxjs/toolkit'
import thunkMiddleware, { ThunkAction, ThunkDispatch } from 'redux-thunk';

export type RootState = ReturnType<typeof usersSlice>
// Створюємо об'єкт Redux store, використовуючи функцію configureStore з бібліотеки Redux Toolkit.
const store = configureStore({
  reducer: usersSlice,
  middleware: [thunkMiddleware],
})
// Визначаємо тип для функції dispatch, яка може обробляти thunk actions.
export type AppDispatch = ThunkDispatch<RootState, unknown, Action<string>>;

// Визначаємо тип для thunk actions, які може обробляти об'єкт store.
export type AppThunk<ReturnType = void> = ThunkAction<
  ReturnType,
  RootState,
  unknown,
  Action<string>
>;

// Експортуємо об'єкт store, щоб його можна було використовувати в інших частинах додатку.
export default store


