import { PayloadAction, createSlice } from "@reduxjs/toolkit"
import { User, getUsers } from "../api/api"
import { AppDispatch } from "../store/store"

    const initialState = {
        user: {
          id: 0,
          name: '',
          email: '',
          gender:'',
          status:'',
        },
        comment:[],
        loading:false,
        error:null,
        popup:false
    }

const userSlice = createSlice({
    name: 'user',
    initialState,
    reducers: {
      requesUsers: (state)=>{
        state.loading=true
      },
      setUser: (state, action: PayloadAction<User>) => {
        state.user=action.payload
        state.loading=false
      },
      setErrorUser:(state, action: PayloadAction<any>)=>{   
        state.error=action.payload
      },
      setPopUp:(state,action:PayloadAction<boolean>)=>{
        state.popup = action.payload
      }
    },
  })
  export const {setUser, requesUsers, setErrorUser,setPopUp}=userSlice.actions

  export const getUser = (id:string) => {
    return async (dispatch: AppDispatch) => {
      try {
        dispatch(requesUsers()); // встановлюємо стан запиту на 'loading'
        const response = await getUsers(id); // виконуємо API-запит для отримання даних про user
        dispatch(setUser(response)); // зберігаємо результати API-запиту в стані
        dispatch(setPopUp(true))
        setTimeout(()=>dispatch(setPopUp(false)),1000)
      } catch (error:any) {
        dispatch(setErrorUser(error.message)); // зберігаємо повідомлення про помилку
      }
    };
  };

  export default userSlice.reducer