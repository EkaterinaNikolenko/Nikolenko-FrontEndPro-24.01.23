import { combineReducers } from '@reduxjs/toolkit'
import usersSlice from './usersSlice'
import { AppDispatch } from '../store/store';
import { useDispatch } from 'react-redux';
const rootReducer = combineReducers({
    user:usersSlice
})
export type RootState = ReturnType<typeof rootReducer>

// Визначаємо тип для функції useDispatch, яка повертає AppDispatch тип зі store.
type UseAppDispatch = () => AppDispatch;

// Експортуємо хук useAppDispatch, який повертає useDispatch<AppDispatch>().
export const useAppDispatch: UseAppDispatch = () => useDispatch<AppDispatch>();