
import { Route, BrowserRouter, Routes, Navigate } from 'react-router-dom';
import {Login} from './components/Login';
import Home from './components/Home';
import InfoMessage from './components/InfoMessage';
import { useSelector } from 'react-redux';
import { RootState } from './store/store';

function App() {
  const isAuthorized = localStorage.getItem('token')
  const popup = useSelector((state:RootState)=>state?.popup)
  const onClick = ()=>{
    localStorage.removeItem('token')
    window.location.href='/login'
  }

  return (
    <BrowserRouter>
          <header><button onClick={onClick}>Sign out</button></header>
    <Routes>
    <Route  path='/'>
    {isAuthorized? <Route path='/' element={<Home/>}  />: <Route path='/' element={<Navigate to='/login' />}/>}
    </Route>
      <Route path='/login' element={<Login />} />
      <Route path='/*' element={<div>Not Found</div>} />
    </Routes>
      {popup && <InfoMessage />}
    </BrowserRouter>
);
}

export default App;
