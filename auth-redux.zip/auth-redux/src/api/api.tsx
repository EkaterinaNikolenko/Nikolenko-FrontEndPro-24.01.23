import axios, { AxiosResponse } from "axios";
import { KEY } from "../key";


export interface User {
  id: number;
  name: string;
  email: string;
  gender:string;
  status:string;
  // Other user properties...
}

export const getUsers = async (id:string): Promise<User|any> => {
  try {
    const headers = {
      Authorization: `Bearer ${KEY}`, // Replace with your actual access token
      "Content-Type": "application/json",
    };

    const response: AxiosResponse<User> = await axios.get(`https://gorest.co.in/public/v2/users/${id}`,{headers});
    return response?.data;
  } catch (error) {
    console.warn('API error', error);
    return error;
  }
};
export const getPosts = async (user:User|null): Promise<User | null> => {
  try {
    const id = localStorage.getItem('token')

    const headers = {
      Authorization: `Bearer ${KEY}`, // Replace with your actual access token
      "Content-Type": "application/json",
    };

    const response: AxiosResponse<User> = await axios.get(`https://gorest.co.in/public/v2/users/${id}/posts`,{headers});
    return response?.data;
  } catch (error) {
    console.warn('API error', error);
    return null;
  }
};



interface UserCreate {
    name: string;
    email: string;
    gender:string;
    status:string;
    // Other user properties...
  }
  
  export const createUser = async (user: UserCreate): Promise<User | null> => {
    try {
      const headers = {
        Authorization: `Bearer ${KEY}`, // Replace with your actual access token
        "Content-Type": "application/json",
      };
  
      const response: AxiosResponse<User> = await axios.post(
        "https://gorest.co.in/public/v2/users",
        user,
        { headers }
      );

      return response.data;
    } catch (error) {
      console.warn('API error', error);
      return null;
    }
  };


  export const setNewPost = async (comment:string): Promise<User | null> => {
    try {
      const token = localStorage.getItem('token')
      const headers = {
        Authorization: `Bearer ${KEY}`, // Replace with your actual access token
        "Content-Type": "application/json",
      };
  
      const response: AxiosResponse<User> = await axios.post(
        `https://gorest.co.in/public/v2/users/${token}/posts`,
        {title:comment,body:comment},
        { headers }
      );
      return response.data;
    } catch (error) {
      console.warn('API error', error);
      return null;
    }
  };