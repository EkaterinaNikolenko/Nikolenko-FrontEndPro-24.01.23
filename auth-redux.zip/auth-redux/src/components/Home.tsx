import React, { useEffect, useState } from 'react';
import {setNewPost } from '../api/api';
import styled from 'styled-components';
import { useSelector } from 'react-redux';
import { RootState } from '../store/store';
import { getUser } from '../reducer/usersSlice';
import { useAppDispatch } from '../reducer/reducers';

 
const HomeContainer = styled.div`

`
const UserBox = styled.div`
padding:10px;
margin-top:20px;
height:fit-content;
width:fit-content;
border: 1px solid black;
border-radius:15px;
margin: 0 auto;
`


export default function Home(): JSX.Element {
  // const [user, setUser] = useState<User | null>(null);
  const dispatch = useAppDispatch()
  const [inputVisible, setInputVisible] = useState(false)
  const {user, loading} = useSelector((state:RootState)=>state)
  const [comment,setComment] = useState('')
  const isAuthorized = localStorage.getItem('token');


  const inputCommentHandler = (event:React.ChangeEvent<HTMLInputElement>)=>{
    event.preventDefault()
    setComment(event.currentTarget.value)
  }
  const onClick = ()=>{
    setNewPost(comment)
  }
  useEffect(() => {
    if (isAuthorized) {
      dispatch(getUser(isAuthorized))
      //reques posts
    }
  }, [isAuthorized]);


  return <HomeContainer>
   {loading?<h4>....Loading</h4>:<UserBox>
      <h3>name: {user?.name}</h3>
      <p>email: {user?.email}</p>
      <p>gender: {user?.gender}</p>
      <p>status: {user?.status}</p>
      {!inputVisible?<button onClick={()=>setInputVisible(true)}>add comment</button>:
      <div><input onChange={inputCommentHandler} value={comment} type="text" placeholder='type you comment' /><button onClick={onClick}>add</button></div>}
    </UserBox>}
    {/* ...вивід коментарів */}
  </HomeContainer>;
}
