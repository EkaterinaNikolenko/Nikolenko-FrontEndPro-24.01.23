import React, { FC, SyntheticEvent, useEffect, useState } from 'react'
import styled from 'styled-components'
import { createUser } from '../api/api'
import {  useNavigate } from 'react-router-dom'
import { useAppDispatch } from '../reducer/reducers'

const LoginContainer = styled.div`
display:flex;
justify-content:center;
align-items:center;
height:100vh;
`
const FormContainer = styled.div`
height:300px;
box-shadow:1px 2px 2px 2px rgb(67, 68, 74, 0.5);
padding:10px;
`
const Form = styled.form`
display:flex;
flex-direction:column;
gap:20px;
`



export const Login = (): JSX.Element => {

    const isAuthorized = localStorage.getItem('token')
    const navigate = useNavigate()
    const dispatch =useAppDispatch()
    useEffect(()=>{
        if(isAuthorized){
        }

    },[navigate,isAuthorized])

   const [credential, setCredential] = useState<{name:string,email:string,gender:string,status:string}>
   ({name:'',email:'',gender:'male',status:'active'})

   const handleInputs = (event:React.FormEvent<HTMLSelectElement|HTMLInputElement>)=>{
    const { name, value } = event.currentTarget; // Destructure name and value from event.currentTarget
    event.preventDefault();
    setCredential((state) => ({ ...state, [name]: value }));
   }
   
   const submitHandler = async (event:React.SyntheticEvent) =>{
    event.preventDefault()
    const data = await createUser(credential)
    if(data){
        localStorage.setItem('token',`${data?.id}`)
        navigate('/')
    }

   }

  return (
    <LoginContainer  >
        <FormContainer onSubmit={submitHandler}>
        <h3>Login</h3>
        <p>Fill inputs</p>
        <Form action="submit">
            <input required onChange={handleInputs} value={credential.name} name='name' type="text" placeholder='name' />
            <input required onChange={handleInputs}  value={credential.email} name='email' type="email" placeholder='email' />
            <select  required onChange={handleInputs}  name="gender" id="gender">
                <option value="male">Male</option>
                <option value="female">Female</option>
            </select>
            <select   required onChange={handleInputs}  name="status" id="sex">
                <option  value="active">Active</option>
                <option value="inactive">Inactive</option>
            </select>
            <button type='submit'>Submit</button>
        </Form>
        </FormContainer>
        </LoginContainer>

  )
}
