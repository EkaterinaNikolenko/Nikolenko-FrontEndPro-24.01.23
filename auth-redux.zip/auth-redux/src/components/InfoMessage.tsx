import React from 'react'
import styled from 'styled-components'

const MessageBox = styled.div`
position:absolute;
top:20px;
right:20px;
width:200px;
height:60px;
background-color:green;
color:white;
`

export default function InfoMessage() {
  return (
    <MessageBox>User succesfuly created</MessageBox>
  )
}
